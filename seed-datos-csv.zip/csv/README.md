# Datos de prueba en CSV

Los mismos datos de la semilla SQL (`datos-simulacion-v3.sql`), en archivos CSV por tabla, para importarlos desde el Table Editor de Supabase.

## Archivos

- users.csv — 6 usuarios (1 Head Advisor, 2 Advisors, 3 Clients)
- clients.csv — 3 clientes (2 active, 1 graduated)
- courses.csv — 3 cursos (ids 1001–1003)
- topics.csv — 12 temas (ids 2001–2012)
- enrollments.csv — 5 inscripciones (ids 3001–3005)
- topic_progress.csv — 20 filas de progreso (ids 4001–4020)
- payments.csv — 5 pagos (ids 5001–5005)
- follow_ups.csv — 4 seguimientos (ids 6001–6004)

Los ids de cursos, temas, inscripciones, progreso, pagos y seguimientos son fijos (1001, 2001, 3001...) para que las relaciones entre archivos cuadren. Los usuarios usan los mismos UUID de la semilla SQL.

## Cómo importarlos

1. En el SQL Editor, ejecuta esto antes de importar. La FK de users a Auth y los triggers estorban la importación (el trigger de clientes y el de progreso crearían filas que luego chocarían con los CSV):

```sql
ALTER TABLE public.users DROP CONSTRAINT IF EXISTS users_id_fkey;
ALTER TABLE public.users DISABLE TRIGGER ALL;
ALTER TABLE public.topics DISABLE TRIGGER ALL;
ALTER TABLE public.enrollments DISABLE TRIGGER ALL;
```

2. En el Table Editor, importa los archivos en este orden, uno por tabla: users → clients → courses → topics → enrollments → topic_progress → payments → follow_ups.

3. En el SQL Editor, ejecuta esto después de importar, para dejar todo como estaba y que los próximos ids no choquen con los de la semilla:

```sql
ALTER TABLE public.users
  ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users (id) ON DELETE CASCADE NOT VALID;
ALTER TABLE public.users ENABLE TRIGGER ALL;
ALTER TABLE public.topics ENABLE TRIGGER ALL;
ALTER TABLE public.enrollments ENABLE TRIGGER ALL;
SELECT setval('courses_id_seq', (SELECT MAX(id) FROM courses));
SELECT setval('topics_id_seq', (SELECT MAX(id) FROM topics));
SELECT setval('enrollments_id_seq', (SELECT MAX(id) FROM enrollments));
SELECT setval('topic_progress_id_seq', (SELECT MAX(id) FROM topic_progress));
SELECT setval('payments_id_seq', (SELECT MAX(id) FROM payments));
SELECT setval('follow_ups_id_seq', (SELECT MAX(id) FROM follow_ups));
```

## Verificación

Debe devolver 6, 3, 3, 5, 5, 4:

```sql
select
  (select count(*) from users where email like '%@example.com') as usuarios_semilla,
  (select count(*) from clients where user_id in (select id from users where email like '%@example.com')) as clientes_semilla,
  (select count(*) from courses where name in ('Full-Stack con Nuxt y Supabase', 'Inglés Conversacional', 'Diseño Gráfico')) as cursos_semilla,
  (select count(*) from enrollments where client_id in (select id from users where email like '%@example.com')) as inscripciones_semilla,
  (select count(*) from payments where enrollment_id in (select id from enrollments where client_id in (select id from users where email like '%@example.com'))) as pagos_semilla,
  (select count(*) from follow_ups where client_id in (select id from users where email like '%@example.com')) as seguimientos_semilla;
```

Nota: los usuarios semilla no pueden iniciar sesión (no tienen cuenta en Auth), solo sirven para probar listas, tablas, reportes y el Home.
